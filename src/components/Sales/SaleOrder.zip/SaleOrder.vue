<template>
  <v-card class="pa-2" outlined>
    <v-card-text>
      <v-row>
        <!-- <v-col cols="12" md="2">
          <label for="txtdocno" class="col-form-label">ที่อยู่(กระจายที่อยู่)</label>
        </v-col> -->
        <v-col cols="12" md="10">
          <v-textarea id="txtdescription"
           rows="5"
           label="ที่อยู่(กระจายที่อยู่)"
           outlined></v-textarea>
        </v-col>
      </v-row>
    </v-card-text>



      <v-row class="mt-4">

        <v-col cols="12" md="4" xl="2">
          <v-btn color="info" style="width:140px;" @click="myGenOrder2">
            <v-icon left>mdi-check</v-icon>กระจายที่อยู่
          </v-btn>
        </v-col>
        <!-- <v-col cols="12" md="4" xl="2">
          <v-btn color="primary" style="width:140px;" id="cmdcrm">
            <v-icon left>mdi-check</v-icon>บันทึกนัดหมาย
          </v-btn>
        </v-col> -->
      </v-row>

      <v-row class="mt-4">
        <v-col cols="12">
          <v-alert type="warning" id="div_error_status" outlined>
          </v-alert>
        </v-col>
      </v-row>



    <v-row>
      <!-- <v-col cols="12" md="2">
        <label for="txtdocno" class="col-form-label">เลขที่เอกสาร</label>
      </v-col> -->
      <v-col cols="12" md="4" xl="2">
        <v-text-field v-model="saleOrderStore.saleorder.docno"
               type="text"
               readonly="readonly"
               label="เลขที่เอกสาร">
               </v-text-field>
      </v-col>
      <!-- <v-col cols="12" md="2">
        <label for="txtdocdate" class="col-form-label">วันที่เอกสาร</label>
      </v-col> -->
      <v-col cols="12" md="4" xl="2">
         <v-text-field v-model="saleOrderStore.saleorder.docdate"
               type="date"
               required
               class="requierd-text"
               label="วันที่สั่งสินค้า"></v-text-field>
      </v-col>
    </v-row>

    <!-- <v-row>
      <v-col cols="12" md="2">
        <label for="combobilltype" class="col-form-label">ประเภทการขาย</label>
      </v-col>
      <v-col cols="12" md="4" xl="2">
        <v-select id="combobilltype" :items="billTypes" outlined></v-select>
      </v-col>
    </v-row> -->

    <v-row>
      <!-- <v-col cols="12" md="2">
        <label for="txtarcode" class="col-form-label">รหัสลูกค้า</label>
      </v-col> -->
      <v-col cols="12" md="4" xl="2">
        <v-text-field v-model="arcode"
               type="text"
               readonly="readonly"
               label="รหัสลูกค้า">
               </v-text-field>
      </v-col>
      <!-- <v-col cols="12" md="2">
        <label for="txtarname" class="col-form-label">ชื่อลูกค้า</label>
      </v-col> -->
      <v-col cols="12" md="4" xl="4">
        <v-text-field v-model="arname"
               type="text"
               readonly="readonly"
               label="ชื่อลูกค้า">
               </v-text-field>
      </v-col>
    </v-row>

    <v-row>
      <v-col cols="12" md="2">
        <label for="txtdeliverypoint" class="col-form-label">รหัสที่ส่ง</label>
      </v-col>
      <v-col cols="12" md="4" xl="2">
        <v-text-field id="txtdeliverypoint" disabled outlined></v-text-field>
      </v-col>
      <v-col cols="12" md="2">
        <label for="txtdeliverypointname" class="col-form-label">ชื่อสถานที่ส่งสินค้า</label>
      </v-col>
      <v-col cols="12" md="4">
        <v-text-field id="txtdeliverypointname" outlined></v-text-field>
      </v-col>
    </v-row>

    <v-row>
      <v-col cols="12" md="2">
        <label for="txtdeliveryaddress" class="col-form-label">สถานที่ส่งสินค้า</label>
      </v-col>
      <v-col cols="12" md="10">
        <v-textarea id="txtdeliveryaddress" rows="3" outlined></v-textarea>
      </v-col>
    </v-row>

    <v-row>
      <v-col cols="12" md="2">
        <label for="txtdeliverytelephone" class="col-form-label">เบอร์โทร</label>
      </v-col>
      <v-col cols="12" md="2">
        <v-text-field id="txtdeliverytelephone" outlined></v-text-field>
      </v-col>
      <v-col cols="12" md="2">
        <label for="combosaleman" class="col-form-label">พนักงานขาย</label>
      </v-col>
      <v-col cols="12" md="4" xl="2">
        <v-select id="combosaleman" :items="salesmen" outlined></v-select>
      </v-col>
    </v-row>

    <v-row>
      <v-col cols="12" md="2">
        <label for="combopaytype" class="col-form-label">การชำระเงิน</label>
      </v-col>
      <v-col cols="12" md="4" xl="2">
        <v-select id="combopaytype" :items="paymentTypes" outlined></v-select>
      </v-col>
      <v-col cols="12" md="2">
        <label for="combobookbank" class="col-form-label">บัญชีที่รับโอน</label>
      </v-col>
      <v-col cols="12" md="4" xl="2">
        <v-select id="combobookbank" :items="bankAccounts" outlined></v-select>
      </v-col>
      <v-col cols="12" md="2">
        <label for="txtamount" class="col-form-label">จำนวนเงิน</label>
      </v-col>
      <v-col cols="12" md="2" xl="2">
        <v-text-field id="txtamount" outlined></v-text-field>
      </v-col>
    </v-row>

    <v-row>
      <v-col cols="12" md="2">
        <label for="txtremark" class="col-form-label">หมายเหตุ</label>
      </v-col>
      <v-col cols="12" md="10">
        <v-textarea id="txtremark" rows="5" outlined></v-textarea>
      </v-col>
    </v-row>

  </v-card>

</template>

<script setup>
import { ref , watch  } from 'vue';
import { defineProps } from 'vue';
import { useSaleOrderStore } from '@/stores/saleOrderStore'; //pin store


const saleOrderStore = useSaleOrderStore(); //pin store => saleOrderStoreStore

const docno = ref('');
const docdate = ref('');
const arcode = ref('');
const arname = ref('');


const statusItems = ref([
 { text: 'ยังไม่โทร', value: 0 },
 { text: 'โทรแล้ว', value: 1 },
]);

const props = defineProps({
 dialogEdit: {
   type: Boolean,
   default : false,
 },
 event: {
   type: Object,
   default: {},
 },

});

const emit = defineEmits(['update:dialogEdit']);



const dialogEdit = ref(props.dialogEdit);
let dialog2 = ref(false);

watch(() => props.dialogEdit, (newVal) => {
 dialogEdit.value = newVal;
});

const handleDialog2 = () => {
  dialog2.value = !dialog2.value;
};


const handleOnConfirm = async () => {

  dialog2.value = false;
  //save event to db
  await saleOrderStore.addEvent(saleOrderStore.saleorder);

  setTimeout(() => {
      saleOrderStore.showNewEventDialog = false;
      saleOrderStore.fetchEvents(saleOrderStore.sale.code);
  }, 1000);

};

const submitEvent = async () => {

//click แล้ว show confirm dialog เฉยๆ จากนั้นจะไปทำ editEvent รับค่าจาก confirmModalDialog อีกที

// console.log("submitEvent");



 //handleBtnSave();


};

</script>

<style scoped>
.requierd-text {
    background-color: pink !important;
}
</style>

